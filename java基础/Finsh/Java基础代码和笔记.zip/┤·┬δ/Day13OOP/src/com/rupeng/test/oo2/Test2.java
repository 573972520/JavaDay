package com.rupeng.test.oo2;

public class Test2
{
	public static void main(String[] args)
	{
		son s1 = new son();
		s1.�����();
		s1.Default����();
		s1.count++;
	}
}
