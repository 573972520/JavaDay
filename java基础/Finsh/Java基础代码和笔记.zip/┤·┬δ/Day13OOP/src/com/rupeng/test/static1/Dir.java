package com.rupeng.test.static1;

public enum Dir
{
	Left,Right,Up,Down
}
