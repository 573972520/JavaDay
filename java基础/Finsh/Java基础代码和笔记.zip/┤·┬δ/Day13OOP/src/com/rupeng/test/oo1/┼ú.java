package com.rupeng.test.oo1;

public class ţ extends animal
{

	public void ����()
	{
		System.out.println("��Ӵ");
	}

}
