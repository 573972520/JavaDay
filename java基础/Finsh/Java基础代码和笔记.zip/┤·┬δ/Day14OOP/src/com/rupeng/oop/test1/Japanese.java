package com.rupeng.oop.test1;

public class Japanese extends earthMan
{
	public void speak()
	{
		System.out.println("�˸�ѽ·");
	}
}
