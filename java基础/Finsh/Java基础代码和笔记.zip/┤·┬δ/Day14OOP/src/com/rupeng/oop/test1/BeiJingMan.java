package com.rupeng.oop.test1;

public class BeiJingMan extends Chinese
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
	}
//	@Override
	public void speak()
	{
		System.out.println("I'm BeiJingMan");
		super.eat();
		super.baiNian();
	}
}
