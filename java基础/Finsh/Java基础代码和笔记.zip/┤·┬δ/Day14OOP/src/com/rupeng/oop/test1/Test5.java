package com.rupeng.oop.test1;

public class Test5
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Chinese c1 = new BeiJingMan();
		c1.speak();
	}

}
