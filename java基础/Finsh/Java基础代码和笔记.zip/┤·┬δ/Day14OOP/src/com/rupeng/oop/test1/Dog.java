package com.rupeng.oop.test1;

public class Dog
{
	public void wangwang()
	{
		System.out.println("����");
	}
}
