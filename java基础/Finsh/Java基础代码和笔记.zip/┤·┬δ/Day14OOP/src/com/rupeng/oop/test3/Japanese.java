package com.rupeng.oop.test3;

public class Japanese extends earthMan
{
	public void sayHello()
	{
		// TODO Auto-generated method stub
		System.out.println("�˸�");
	}
}
