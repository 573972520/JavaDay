package com.rupeng.oop.test3;

public class Test2
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		earthMan man = new MoSiKeRen();
		man.sayHello();
		
		//earthMan man2 = new ErGuoRen();//�������޷���new
		
	}

}
