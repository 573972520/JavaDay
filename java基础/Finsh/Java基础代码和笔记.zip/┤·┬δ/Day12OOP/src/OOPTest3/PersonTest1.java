package OOPTest3;

public class PersonTest1
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		/*
		Person p1 = new Person();
		p1.setAge(5);
		p1.setName("fuck");
		p1.sayHello();
		
		int i = p1.getAge(); //�õ�����
		i--;
		p1.setAge(i); //��������
		p1.sayHello();
		p1.setAge(p1.getAge()-1);	
		p1.sayHello();
		*/
		/*
		//��Ӧpublic
		Person p1 = new Person();
		p1.age =5;
		p1.name = "FUCK";
		p1.sayHello();
		p1.age = p1.age + 1;
		p1.sayHello();
		p1.age++;
		p1.sayHello();
		*/
		/*
		Person p1 = new Person();
		p1.age = -1;
		p1.name = "asfasfdsfgjhhskjvsdbkjgfbsdjkovbds64+5645";
		p1.sayHello();
		*/
		
		Person p1 = new Person();
		p1.setAge(-45);
		p1.setName("asdwaqs5644asd");
		p1.sayHello();
		
	}

}
