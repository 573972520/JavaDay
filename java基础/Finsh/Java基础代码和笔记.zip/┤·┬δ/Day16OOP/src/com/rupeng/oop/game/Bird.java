package com.rupeng.oop.game;

public class Bird implements Flyable
{

	@Override
	public void fly()
	{
		// TODO Auto-generated method stub
		System.out.println("����һֻС���ҷɰ���");
	}

}
