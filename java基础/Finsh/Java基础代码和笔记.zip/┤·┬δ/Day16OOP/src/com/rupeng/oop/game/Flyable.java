package com.rupeng.oop.game;

public interface Flyable
{
	void fly();
}
