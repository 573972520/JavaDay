package com.rupeng.oop.test1;

public interface Eatable
{
	void eat();
}
