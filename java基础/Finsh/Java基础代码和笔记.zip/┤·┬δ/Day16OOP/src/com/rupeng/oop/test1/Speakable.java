package com.rupeng.oop.test1;

public interface Speakable
{
	void speak(String name);
	void cry();
}
