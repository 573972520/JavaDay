package com.rupeng.oop.test1;

public interface Personable extends Eatable, Speakable
{
	public static int age = 8;
	public static final int i = 9;
	void jump();
}
