package com.rupeng.oop.test1;

public class AAA implements Personable //Ҫʵ�����еķ���
{

	@Override
	public void eat()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void speak(String name)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cry()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void jump()
	{
		// TODO Auto-generated method stub
		
	}

	

}
