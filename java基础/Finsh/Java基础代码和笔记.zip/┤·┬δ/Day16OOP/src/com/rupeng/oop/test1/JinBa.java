package com.rupeng.oop.test1;

public class JinBa extends Dog implements Eatable
{
	@Override
	public void eat()
	{
		// TODO Auto-generated method stub
		
	}
}
