package com.rupeng.oop.test;

public class Chinese extends earthMan
{
	@Override
	public void speak()
	{
		// TODO Auto-generated method stub
		
	}
}
